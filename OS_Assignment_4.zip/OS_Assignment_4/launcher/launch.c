#include "../loader/loader.h"


// check if the elf file matches the magic no. and is of 32-bit executable
int elf_check_file(Elf32_Ehdr *ehdr_temp) {
    if(!ehdr_temp) return 0;

    if(ehdr_temp->e_ident[EI_MAG0] != ELFMAG0) {
        printf("Elf Header EI_MAG0 incorrect.\n");
        return 0;
    }
    if(ehdr_temp->e_ident[EI_MAG1] != ELFMAG1) {
        printf("Elf Header EI_MAG1 incorrect.\n");
        return 0;
    }
    if(ehdr_temp->e_ident[EI_MAG2] != ELFMAG2) {
        printf("Elf Header EI_MAG2 incorrect.\n");
        return 0;
    }
    if(ehdr_temp->e_ident[EI_MAG3] != ELFMAG3) {
        printf("Elf Header EI_MAG3 incorrect.\n");
        return 0;
    }
    if (ehdr_temp->e_ident[EI_CLASS] != ELFCLASS32) {
        printf("Not a 32-bit ELF file.\n");
        return 0;
    }
    return 1;
}


int main(int argc, char** argv) 
{
    if(argc != 2) {
        
        printf("Usage: %s <ELF Executable> \n",argv[0]);
        exit(1);
    }
    // 1. carry out necessary checks on the input ELF file

    // create a temporary ehdr to validate the elf file by going through the 
    // elf header
    Elf32_Ehdr *ehdr_temp;
    int fd_temp = open(argv[1], O_RDONLY);  // open in read only mode
    ehdr_temp = (Elf32_Ehdr*) malloc(sizeof(Elf32_Ehdr));
    lseek(fd_temp, 0, SEEK_SET);


    // read the binary content
    if (read(fd_temp, ehdr_temp, sizeof(Elf32_Ehdr)) != sizeof(Elf32_Ehdr)) {
        printf("Failed to read Elf Header\n");
    }
    
    int check = elf_check_file(ehdr_temp);
    if (!check) {
        printf("Elf file is not valid\n");
        exit(1);
    }
    // clean up memory allocated for temporary variables to check elf file
    if (fd_temp >= 0) {
        close(fd_temp);
    }
    free(ehdr_temp);
    
    // 2. passing it to the loader for carrying out the loading/execution
    load_and_run_elf(argv);
    
    // 3. invoke the cleanup routine inside the loader  
    loader_cleanup(argv);
    return 0;
}
