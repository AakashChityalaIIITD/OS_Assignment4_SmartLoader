/*
 * No changes are allowed to this file
 */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <elf.h>
#include <string.h>
#include <stdint.h>


void load_and_run_elf(char** exe);
void loader_cleanup();
