#include "loader.h"

#define PAGE_SIZE 4096  // Page size in bytes
#define MAX_MAPPED_PAGES 1024

Elf32_Ehdr *ehdr = NULL;
Elf32_Phdr *phdr = NULL;
int fd = -1;
int page_faults = 0;
int page_allocations = 0;
int internal_fragmentation = 0;
void *mapped_pages[MAX_MAPPED_PAGES];
int mapped_page_count = 0;

void handle_fault(int sig, siginfo_t *si, void *unused);
void setup_signal_handler();
void load_segment_on_demand(void *fault_addr);
void execute_start();
void free_mapped_memory();

void load_and_run_elf(char **exe) {
    fd = open(exe[1], O_RDONLY);
    if (fd < 0) {
        perror("Failed to open ELF file");
        exit(1);
    }

    ehdr = (Elf32_Ehdr *)malloc(sizeof(Elf32_Ehdr));
    if (!ehdr || read(fd, ehdr, sizeof(Elf32_Ehdr)) != sizeof(Elf32_Ehdr)) {
        perror("Failed to read ELF header");
        exit(1);
    }

    phdr = (Elf32_Phdr *)malloc(sizeof(Elf32_Phdr) * ehdr->e_phnum);
    lseek(fd, ehdr->e_phoff, SEEK_SET);
    if (!phdr || read(fd, phdr, sizeof(Elf32_Phdr) * ehdr->e_phnum) != sizeof(Elf32_Phdr) * ehdr->e_phnum) {
        perror("Failed to read program headers");
        exit(1);
    }

    setup_signal_handler();
    execute_start();
    loader_cleanup();
    free_mapped_memory();

    printf("Execution completed.\n");
    printf("Page faults: %d\n", page_faults);
    printf("Page allocations: %d\n", page_allocations);
    printf("Internal fragmentation: %d KB\n", internal_fragmentation / 1024);
}

void setup_signal_handler() {
    struct sigaction sa;
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = handle_fault;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGSEGV, &sa, NULL) == -1) {
        perror("Failed to set up SIGSEGV handler");
        exit(1);
    }
}

void handle_fault(int sig, siginfo_t *si, void *unused) {
    void *fault_addr = si->si_addr;
    page_faults++;
    load_segment_on_demand(fault_addr);
}

void load_segment_on_demand(void *fault_addr) {
    for (int i = 0; i < ehdr->e_phnum; i++) {
        if (phdr[i].p_type == PT_LOAD &&
            fault_addr >= (void *)phdr[i].p_vaddr &&
            fault_addr < (void *)(phdr[i].p_vaddr + phdr[i].p_memsz)) {

            uintptr_t page_start = (uintptr_t)fault_addr & ~(PAGE_SIZE - 1);
            size_t offset = phdr[i].p_offset + (page_start - phdr[i].p_vaddr);

            if (mapped_page_count < MAX_MAPPED_PAGES) {
                void *mapped_addr = mmap((void *)page_start, PAGE_SIZE,
                                         PROT_READ | PROT_WRITE | PROT_EXEC,
                                         MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
                if (mapped_addr == MAP_FAILED) {
                    perror("mmap failed during page fault handling");
                    exit(1);
                }

                mapped_pages[mapped_page_count++] = mapped_addr;

                lseek(fd, offset, SEEK_SET);
                read(fd, mapped_addr, PAGE_SIZE);
                page_allocations++;

                if (page_start + PAGE_SIZE > phdr[i].p_vaddr + phdr[i].p_memsz) {
                    internal_fragmentation += page_start + PAGE_SIZE - (phdr[i].p_vaddr + phdr[i].p_memsz);
                }

                return;
            } else {
                fprintf(stderr, "Exceeded maximum mapped pages limit\n");
                exit(1);
            }
        }
    }

    fprintf(stderr, "Invalid memory access at %p\n", fault_addr);
    exit(1);
}

void execute_start() {
    int (*entry)() = (int (*)())ehdr->e_entry;
    int result = entry();
    printf("User _start return value: %d\n", result);
}

void loader_cleanup() {
    if (fd >= 0) close(fd);
    if (ehdr) free(ehdr);
    if (phdr) free(phdr);
    ehdr = NULL;
    phdr = NULL;
}

void free_mapped_memory() {
    for (int i = 0; i < mapped_page_count; i++) {
        if (mapped_pages[i] != NULL) {
            if (munmap(mapped_pages[i], PAGE_SIZE) == -1) {
                perror("munmap failed");
                exit(1);
            }
            mapped_pages[i] = NULL;
        }
    }
    mapped_page_count = 0;
}
